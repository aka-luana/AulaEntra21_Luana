# **Exercícios**
# Dada a seguinte lista, resolva os seguintes questões:
# EXECUTE ESTE QUADRO PARA PODER USAR A LISTA

# Link do meu git: https://github.com/aka-luana/AulaEntra21_Luana

lista = [10, 20, 'amor', 'abacaxi', 80, 'Abioluz', 'Cachorro grande é de arrasar']

# 1) Usando a indexação, escreva na tela a palavra abacaxi
print(f"O elemento do index 3 é o {lista[3]}")

# 2) Usando a indexação, escreva na tela os seguintes dados: 20, amor, abacaxi
print(f"Os elemento 1, 2 e 3 são respectivamente {lista[1:4]}")

# 3) Usando a indexação, escreva na tela uma lista com dados de 20 até Abioluz
print(f"Os elementos de '20 - Abioluz' são: {lista[1:6]}")

# 4) Usando a indexação, escreva na tela os seguintes dados:
# 10, amor, 80, Cachorro grande é de arrasar
print(f"Os dados são: {lista[::2]}")

# 5) Usando a indexação escreva na tela os seguintes dados:
# amor - 10 - 10 - abacaxi - Cachorro grande é de arrasar - Abioluz - 10 - 20
print(f"{lista[2]} - {lista[0]} - {lista[0]} - {lista[3]} - {lista[6]} - {lista[5]} - {lista[0]} - {lista[1]}")

# 6) Usando a indexação, escreva na tela uma lista com dados de 10 até 80
print(f"Os elementos são: {lista[0:5]}")

# 7) Usando a indexação, escreva na tela os seguintes dados:
# 10, abacaxi, Cachorro grande é de arrasar
print(f"Os dados são: {lista[::3]}")
