
# ---------------------
# 
# Exercícios
# 
# ---------------------

# 1) Crie uma lista vazia.
# 
# Adicione as 3 palavras "Abacate" , "Dia bonito",  "Maria Tereza" , usando o .append() em cada uma destas palavras separadamente.

# Link do meu git: https://github.com/aka-luana/AulaEntra21_Luana

lista = []

lista.append("Abacate")
lista.append("Dia bonito")
lista.append("Maria Tereza")

print(lista)
