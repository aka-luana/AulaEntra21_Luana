# 2) Crie uma lista com 10 números qualquer.
# 
# Usando as funções da lista responda:
# 
# Quantos itens tem a lista?
# Qual é o número maior?
# Qual é o número menor?
# Qual é o resultado da soma da lista?
#

# Link do meu git: https://github.com/aka-luana/AulaEntra21_Luana

listaQualquer = [1, 9, 42, 0.5, 6, 17, 13, 0, 2, 19]

print(f"Quantos itens tem na lista? R: {len(listaQualquer)}")
print(f"Qual é o maior número na lista? R: {max(listaQualquer)}")
print(f"Qual é o menor número na lista? R: {min(listaQualquer)}")
print(f"Qual é o resultado da soma da lista? R: {sum(listaQualquer)}")
